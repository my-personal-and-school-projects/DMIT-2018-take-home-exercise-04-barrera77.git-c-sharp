﻿// ***********************************************************************
// Assembly         : ERaceLibrary
// Author           : 
// Created          : 03-16-2024
//
// Last Modified By : 
// Last Modified On : 03-16-2024
// ***********************************************************************
// <copyright file="MemberService.cs" company="ERaceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace ERaceLibrary.BLL
{
    /// <summary>
    /// Class MemberService.
    /// </summary>
    public class MemberService
    {
    }
}
