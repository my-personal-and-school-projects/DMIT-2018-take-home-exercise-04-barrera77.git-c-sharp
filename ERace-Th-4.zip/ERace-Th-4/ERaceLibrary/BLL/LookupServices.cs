﻿namespace ERaceLibrary.BLL
{
    public class LookupServices
    {
        //  GetCertificationLookups()
		// GetCarClassLookups()
    }
}
